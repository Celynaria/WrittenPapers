package entities;

import java.util.Map;

public class TaxiDriver {

	private String driverID;
	private String firstName;
	private String lastName;
	public String getDriverID() {
		return driverID;
	}
	public TaxiDriver(String driverID, String name, String lastName) {
		super();
		this.driverID = driverID;
		this.firstName = name;
		this.lastName = lastName;
	}
	public void setDriverID(String driverID) {
		this.driverID = driverID;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String name) {
		this.firstName = name;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public static Map<String, TaxiDriver> read(){
		return null;
	}
	
}

package entities;

import java.util.Map;

public class Taxi {

	private String registrationID;
	private TaxiDriver taxiDriver;
	private String taxiType;
	private int maximumPassenger;
	
	public Taxi(String registrationID, TaxiDriver taxiDriver, String taxiType,
			int maximumPassenger) {
		super();
		this.registrationID = registrationID;
		this.taxiDriver = taxiDriver;
		this.taxiType = taxiType;
		this.maximumPassenger = maximumPassenger;
	}
	public String getRegistrationID() {
		return registrationID;
	}
	public void setRegistrationID(String registrationID) {
		this.registrationID = registrationID;
	}
	public TaxiDriver getTaxiDriver() {
		return taxiDriver;
	}
	public void setTaxiDriver(TaxiDriver taxiDriver) {
		this.taxiDriver = taxiDriver;
	}
	public String getTaxiType() {
		return taxiType;
	}
	public void setTaxiType(String taxiType) {
		this.taxiType = taxiType;
	}
	public int getMaximumPassenger() {
		return maximumPassenger;
	}
	public void setMaximumPassenger(int maximumPassenger) {
		this.maximumPassenger = maximumPassenger;
	}
	public static Map<String, Taxi> read(Map<String, TaxiDriver> drivers){
		return null;
	}
}

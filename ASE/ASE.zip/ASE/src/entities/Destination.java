package entities;

import java.util.Map;

public class Destination {

	public String name;
	public double distance;

	public Destination(String name, double distance) {
		super();
		this.name = name;
		this.distance = distance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(double distance) {
		this.distance = distance;
	}
	public static Map<String, Destination> read(){
		return null;
	}
}

package entities;

import java.util.Date;
import java.util.List;
import java.util.Map;

public class Journey {

	private Taxi taxi;
	private Destination destination;
	private double fee;
	private Date date;
	private int numberOfPassenger = 1;
	
	public Journey(Taxi taxi, Destination destination, Date date,int numberOfPassenger) {
		super();
		this.taxi = taxi;
		this.destination = destination;
		this.date = date;
		this.numberOfPassenger = numberOfPassenger;
		this.fee = feeCalculation();
	}
	public Taxi getTaxi() {
		return taxi;
	}
	public void setTaxi(Taxi taxi) {
		this.taxi = taxi;
	}
	public Destination getDestination() {
		return destination;
	}
	public void setDestination(Destination destination) {
		this.destination = destination;
	}
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public int getNumberOfPassenger() {
		return numberOfPassenger;
	}
	public void setNumberOfPassenger(int numberOfPassenger) {
		this.numberOfPassenger = numberOfPassenger;
	}
	public double feeCalculation(){
		return fee;
	}
	public static List<Journey> read(Map<String, Destination> destinations, Map<String, Taxi> taxies) {
		return null;
	}
	
	
}

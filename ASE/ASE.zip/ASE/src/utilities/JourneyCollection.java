package utilities;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import entities.Destination;
import entities.Journey;
import entities.Taxi;
import entities.TaxiDriver;

public class JourneyCollection {

	private List<Journey> journeys = new ArrayList<Journey>();
	
	public boolean loadData(){
		Map<String, Destination> destinations = Destination.read();
		Map<String, TaxiDriver> drivers = TaxiDriver.read();
		Map<String, Taxi> taxis = Taxi.read(drivers);
		journeys = Journey.read(destinations,taxis);
		return false;
	}
	public boolean rankingReport(){
		return false;
	}
	public boolean driverReport(){
		return false;
	}
	public boolean visitedReport(){
		return false;
	}
}

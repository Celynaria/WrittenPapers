package main;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;

import javafx.collections.transformation.SortedList;

public class JourneyBegin {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	}

}
